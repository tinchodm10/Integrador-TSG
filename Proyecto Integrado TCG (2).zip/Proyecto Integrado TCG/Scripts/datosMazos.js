/* ================================
   📘 datosMazos.js
   Contiene la información completa
   de los mazos de "Reinos del Oro".
   ================================ */

// 🔹 Datos base de los mazos
const mazos = [
  {
    monarca: "Aurelion, el Radiante",
    reino: "Sol Dorado",
    unidades: [
      { nombre: "Caballero del Alba", costo: 2, ataque: 2, defensa: 3, cantidad: 3 },      // Balanceado defensor
      { nombre: "Paladín de la Aurora", costo: 4, ataque: 4, defensa: 4, cantidad: 3 },    // Unidad premium balanceada
      { nombre: "Escudero Luminoso", costo: 1, ataque: 1, defensa: 2, cantidad: 3 },       // Defensor básico
      { nombre: "Lancero Solar", costo: 2, ataque: 3, defensa: 2, cantidad: 3 },           // Atacante moderado
      { nombre: "Jinete del Alba", costo: 3, ataque: 3, defensa: 3, cantidad: 3 }
    ],
    recursos: [
      { nombre: "Mina de Oro Real", costo: 0, efecto: "Produce 2 de oro por turno.", cantidad: 1 },
      { nombre: "Ruta Comercial de los Siete Desiertos", costo: 0, efecto: "Duplica la ganancia de oro si no atacas.", cantidad: 1 },
      { nombre: "Mercado Dorado", costo: 0, efecto: "Permite cambiar una carta de tu mano por otra del mazo.", cantidad: 1 },
      { nombre: "Finca del Sol", costo: 0, efecto: "Produce 1 oro y cura 1 punto de defensa a una unidad.", cantidad: 1 },
      { nombre: "Caravana Comercial", costo: 0, efecto: "Gana +1 oro si controlas más estructuras que el enemigo.", cantidad: 1 }
    ],
    estructuras: [
      { nombre: "Muralla de Luz", costo: 3, defensa: 4, efecto: "Aumenta +1 defensa a todas tus tropas.", cantidad: 2 },
      { nombre: "Templo del Sol Eterno", costo: 3, defensa: 3, efecto: "Aumenta +1 defensa al castillo.", cantidad: 2 },
      { nombre: "Torre del Amanecer", costo: 2, defensa: 2, efecto: "Aumenta +1 ataque a una tropa aliada.", cantidad: 2 },
      { nombre: "Faro de Brillo", costo: 2, defensa: 2, efecto: "Reduce -1 defensa a una tropa enemiga.", cantidad: 2 },
      { nombre: "Santuario del Alba", costo: 3, defensa: 3, efecto: "Aumenta +1 defensa a una tropa aliada.", cantidad: 2 }
    ],
    hechizos: [
      { nombre: "Bendición Solar", costo: 2, efecto: "Aumenta +2 defensa a una tropa aliada.", cantidad: 3 },
      { nombre: "Tormenta de Luz", costo: 3, efecto: "Reduce -2 defensa a una tropa enemiga.", cantidad: 3 },
      { nombre: "Escudo de Luz", costo: 2, efecto: "Aumenta +2 defensa al castillo por un turno.", cantidad: 3 },
      { nombre: "Destello Solar", costo: 3, efecto: "Reduce -3 defensa a una tropa enemiga.", cantidad: 3 },
      { nombre: "Llamado del Alba", costo: 2, efecto: "Aumenta +1 ataque a todas tus tropas por un turno.", cantidad: 3 }
    ]
  },
  {
    monarca: "Valgor, el Conquistador",
    reino: "Hierro Carmesí",
    unidades: [
      { nombre: "Soldado de Hierro", costo: 2, ataque: 3, defensa: 2, cantidad: 3 },       // Atacante moderado
      { nombre: "Hacha de Acero", costo: 3, ataque: 3, defensa: 3, cantidad: 3 },          // Balanceado medio
      { nombre: "Lancero de Forja", costo: 2, ataque: 2, defensa: 3, cantidad: 3 },        // Defensor moderado
      { nombre: "Artillero Blindado", costo: 3, ataque: 4, defensa: 2, cantidad: 3 },      // Atacante fuerte pero frágil
      { nombre: "Gólem de Forja", costo: 4, ataque: 4, defensa: 4, cantidad: 3 }
    ],
    recursos: [
      { nombre: "Mina de Acero Oscuro", costo: 0, efecto: "Produce 2 de hierro por turno.", cantidad: 2 },
      { nombre: "Fábrica de Engranes", costo: 0, efecto: "Si no atacas, produce 1 recurso adicional.", cantidad: 2 },
      { nombre: "Fundición del Martillo Rojo", costo: 0, efecto: "Genera 1 hierro y aumenta +1 ataque a una unidad.", cantidad: 2 },
      { nombre: "Depósito de Chatarra", costo: 0, efecto: "Recupera 1 defensa a una estructura.", cantidad: 2 },
      { nombre: "Ruta del Carbón", costo: 0, efecto: "Produce +1 recurso si controlas más estructuras.", cantidad: 2 }
    ],
    estructuras: [
      { nombre: "Muralla de Acero", costo: 3, defensa: 4, efecto: "Aumenta +1 defensa a tus tropas.", cantidad: 2 },
      { nombre: "Fortaleza del Martillo", costo: 4, defensa: 5, efecto: "Aumenta +1 ataque a tus tropas.", cantidad: 2 },
      { nombre: "Pilar del Vapor", costo: 3, defensa: 3, efecto: "Reduce -1 defensa a una tropa enemiga.", cantidad: 2 },
      { nombre: "Foso de Engranajes", costo: 2, defensa: 2, efecto: "Reduce -1 ataque a una tropa enemiga.", cantidad: 2 },
      { nombre: "Bastión de Hierro", costo: 5, defensa: 5, efecto: "Aumenta +2 defensa a tus estructuras.", cantidad: 2 }
    ],
    hechizos: [
      { nombre: "Martillo Ardiente", costo: 3, efecto: "Reduce -3 defensa a una tropa enemiga.", cantidad: 3 },
      { nombre: "Blindaje de Hierro", costo: 2, efecto: "Aumenta +2 defensa a una tropa aliada.", cantidad: 3 },
      { nombre: "Explosión de Forja", costo: 3, efecto: "Reduce -2 defensa a todas las tropas enemigas.", cantidad: 3 },
      { nombre: "Refuerzo Mecánico", costo: 2, efecto: "Aumenta +2 defensa a una estructura.", cantidad: 3 },
      { nombre: "Descarga Eléctrica", costo: 3, efecto: "Reduce -2 defensa a una tropa enemiga.", cantidad: 3 }
    ]
  }
];


// 🔸 Guardar el mazo seleccionado en localStorage
function seleccionarMazo(nombreReino) {
  const mazo = mazos.find(m => m.reino === nombreReino);
  if (mazo) {
    localStorage.setItem("mazoSeleccionado", JSON.stringify(mazo));
    console.log(`Mazo de ${nombreReino} guardado en localStorage`);
  } else {
    console.error("No se encontró el mazo:", nombreReino);
  }
}

// 🔸 Obtener el mazo seleccionado
function obtenerMazoSeleccionado() {
  const data = localStorage.getItem("mazoSeleccionado");
  return data ? JSON.parse(data) : null;
}

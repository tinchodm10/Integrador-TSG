class Juego {
    constructor() {
        this.mazoJugador = null;
        this.mazoIA = null;
        this.cartasRestantesJugador = [];
        this.cartasRestantesIA = [];
        this.manoJugador = [];
        this.manoIA = [];
        this.cartaSeleccionada = null;
        this.turnoJugador = true;
        this.oroJugador = 2;
        this.oroIA = 2;

        // Estado del tablero
        this.tableroJugador = {
            tropas: new Array(3).fill(null),
            estructuras: new Array(2).fill(null),
            castillo: { vida: 30 },
            tropasAtacaron: new Array(3).fill(false)
        };

        this.tableroIA = {
            tropas: new Array(3).fill(null),
            estructuras: new Array(2).fill(null),
            castillo: { vida: 30 },
            tropasAtacaron: new Array(3).fill(false)
        };
    }

    inicializarJuego() {
        // Asignamos mazos fijos para pruebas
        this.mazoJugador = mazos[0]; // Aurelion
        this.mazoIA = mazos[1]; // Valgor

        // Repartir cartas iniciales
        this.repartirCartasIniciales();
        
        // Actualizar interfaz
        this.actualizarInterfaz();

        // Si la IA empieza primero
        if (!this.turnoJugador) {
            setTimeout(() => this.turnoIA(), 1000);
        }
    }

    repartirCartasIniciales() {
        // Solo usaremos unidades para pruebas de combate
        const unidadesJugador = [...this.mazoJugador.unidades];
        const unidadesIA = [...this.mazoIA.unidades];

        // Repartir cartas iniciales (máximo 4)
        for (let i = 0; i < 4; i++) {
            if (unidadesJugador.length > 0 && this.manoJugador.length < 4) {
                const randomIndex = Math.floor(Math.random() * unidadesJugador.length);
                this.manoJugador.push(unidadesJugador[randomIndex]);
                unidadesJugador.splice(randomIndex, 1);
            }
            
            if (unidadesIA.length > 0 && this.manoIA.length < 4) {
                const randomIndex = Math.floor(Math.random() * unidadesIA.length);
                this.manoIA.push(unidadesIA[randomIndex]);
                unidadesIA.splice(randomIndex, 1);
            }
        }

        // El resto de unidades van al mazo
        this.cartasRestantesJugador = unidadesJugador;
        this.cartasRestantesIA = unidadesIA;

        // Decidir quién empieza
        this.turnoJugador = Math.random() < 0.5;
    }

    actualizarInterfaz() {
        // Limpiar las clases de estado
        document.querySelectorAll('.carta').forEach(carta => {
            carta.classList.remove('puede-atacar', 'objetivo-valido', 'ya-ataco');
        });

        // Actualizar el botón de terminar turno
        const btnTerminarTurno = document.getElementById('btn-terminar-turno');
        if (btnTerminarTurno) {
            btnTerminarTurno.disabled = !this.turnoJugador;
            btnTerminarTurno.textContent = this.turnoJugador ? 'Terminar Turno' : 'Turno del Oponente';
        }

        // Actualizar mano del jugador
        const manoDiv = document.querySelector('.mano');
        manoDiv.innerHTML = '';
        
        this.manoJugador.forEach((carta, index) => {
            const cartaDiv = document.createElement('div');
            cartaDiv.className = 'carta';
            cartaDiv.innerHTML = this.crearHTMLCarta(carta);
            cartaDiv.onclick = () => this.seleccionarCarta(carta, index);
            manoDiv.appendChild(cartaDiv);
        });

        // Actualizar tropas en el tablero
        const tropasJugador = document.querySelectorAll('.fila.tropas')[1].children;
        const tropasIA = document.querySelectorAll('.fila.tropas')[0].children;

        // Actualizar tropas del jugador
        for(let i = 0; i < this.tableroJugador.tropas.length; i++) {
            const tropa = this.tableroJugador.tropas[i];
            if (tropa) {
                tropasJugador[i].innerHTML = this.crearHTMLCarta(tropa);
                if (this.tableroJugador.tropasAtacaron[i]) {
                    tropasJugador[i].classList.add('ya-ataco');
                }
            } else {
                tropasJugador[i].innerHTML = `Tropa ${i + 1}`;
            }
        }

        // Actualizar tropas de la IA
        for(let i = 0; i < this.tableroIA.tropas.length; i++) {
            const tropa = this.tableroIA.tropas[i];
            if (tropa) {
                tropasIA[i].innerHTML = this.crearHTMLCarta(tropa);
                tropasIA[i].classList.add('carta-rival');
            } else {
                tropasIA[i].innerHTML = `Tropa ${i + 1}`;
            }
        }

        // Actualizar estructuras del jugador
        const estructurasJugador = document.querySelectorAll('.fila.estructuras')[1].children;
        for(let i = 0; i < this.tableroJugador.estructuras.length; i++) {
            const estructura = this.tableroJugador.estructuras[i];
            if (estructura) {
                estructurasJugador[i].innerHTML = this.crearHTMLCarta(estructura);
            } else {
                estructurasJugador[i].innerHTML = `Estructura ${i + 1}`;
            }
        }

        // Actualizar estructuras de la IA
        const estructurasIA = document.querySelectorAll('.fila.estructuras')[0].children;
        for(let i = 0; i < this.tableroIA.estructuras.length; i++) {
            const estructura = this.tableroIA.estructuras[i];
            if (estructura) {
                estructurasIA[i].innerHTML = this.crearHTMLCarta(estructura);
            } else {
                estructurasIA[i].innerHTML = `Estructura ${i + 1}`;
            }
        }

        // Actualizar vida de los castillos
        const castilloJugador = document.querySelector('.castillo.propio .hp');
        const castilloIA = document.querySelector('.castillo.enemigo .hp');
        
        castilloJugador.textContent = `❤️ ${this.tableroJugador.castillo.vida} HP`;
        castilloIA.textContent = `❤️ ${this.tableroIA.castillo.vida} HP`;

        // Actualizar oro de ambos jugadores
        const oroJugadorSpan = document.getElementById('oro-cantidad');
        if (oroJugadorSpan) {
            oroJugadorSpan.textContent = this.oroJugador;
        }
        const oroIASpan = document.getElementById('oro-ia');
        if (oroIASpan) {
            oroIASpan.textContent = this.oroIA;
        }

        // Actualizar indicador de turno
        const turnoDiv = document.querySelector('.turno');
        if (turnoDiv) {
            turnoDiv.textContent = this.turnoJugador ? 'Tu Turno' : 'Turno del Oponente';
        }

        // Hacer las cartas interactivas si es el turno del jugador
        if (this.turnoJugador) {
            this.hacerCartasInteractivas();
        }

        // Verificar victoria
        if (this.tableroIA.castillo.vida <= 0) {
            alert('¡Has ganado!');
            location.reload();
        } else if (this.tableroJugador.castillo.vida <= 0) {
            alert('Has perdido...');
            location.reload();
        }
    }

    robarCarta(esJugador) {
        const mazo = esJugador ? this.cartasRestantesJugador : this.cartasRestantesIA;
        const mano = esJugador ? this.manoJugador : this.manoIA;
        
        // Verificar límite de cartas en mano
        if (mano.length >= 4) {
            return false;
        }
        
        if (mazo.length > 0) {
            const indiceRandom = Math.floor(Math.random() * mazo.length);
            const cartaRobada = mazo[indiceRandom];
            mazo.splice(indiceRandom, 1);
            mano.push(cartaRobada);
            return true;
        }
        return false;
    }

    crearHTMLCarta(carta) {
        if (!carta || typeof carta !== 'object') {
            console.error('Carta inválida:', carta);
            return 'Error: Carta inválida';
        }

        try {
            let html = `<h3>${carta.nombre}</h3>`;
            // En esta versión de prueba solo mostramos unidades
            html += `
                <p>Costo: ${carta.costo} 🪙</p>
                <p>ATK: ${carta.ataque} | DEF: ${carta.defensa}</p>
            `;
            return html;
        } catch (error) {
            console.error('Error al crear HTML de la carta:', error);
            return 'Error: Carta inválida';
        }
    }

    seleccionarCarta(carta, index) {
        if (!this.turnoJugador) return;

        // Verificar que sea una unidad
        if (!('ataque' in carta)) {
            alert('Solo se pueden jugar unidades en esta versión de prueba');
            return;
        }

        // Verificar si tiene suficiente oro
        if (carta.costo !== 0 && carta.costo > this.oroJugador) {
            alert('¡No tienes suficiente oro para jugar esta carta!');
            return;
        }

        const cartaHTML = this.crearHTMLCarta(carta);
        
        // Solo manejamos tropas
        const zonaTropas = document.querySelectorAll('.fila.tropas')[1].children;
        // Buscar un espacio vacío
        for (let i = 0; i < zonaTropas.length; i++) {
            if (zonaTropas[i].textContent === 'Tropa ' + (i + 1)) {
                this.tableroJugador.tropas[i] = carta;
                this.manoJugador.splice(index, 1);
                // Descontar el oro
                this.oroJugador -= carta.costo;
                // Robar una nueva carta si no excede el límite
                if (this.manoJugador.length < 4) {
                    this.robarCarta(true);
                }
                this.actualizarInterfaz();
                return;
            }
        }
}

// Función para el turno de la IA
    turnoIA() {
        if (this.manoIA.length === 0) {
            this.finalizarTurno();
            return;
        }

        // Buscar cartas que podamos pagar
        let cartasJugables = [];
        
        for (let i = 0; i < this.manoIA.length; i++) {
            const carta = this.manoIA[i];
            if (carta.costo <= this.oroIA && 'ataque' in carta) {
                cartasJugables.push({ carta, indice: i });
            }
        }

        // Elegir una carta al azar entre las que podemos pagar (70% de probabilidad de elegir la más cara)
        let cartaJugable = null;
        let indiceCarta = -1;

        if (cartasJugables.length > 0) {
            if (Math.random() < 0.7) {
                // Elegir la carta más cara
                cartasJugables.sort((a, b) => b.carta.costo - a.carta.costo);
                cartaJugable = cartasJugables[0].carta;
                indiceCarta = cartasJugables[0].indice;
            } else {
                // Elegir una carta al azar
                const randomIndex = Math.floor(Math.random() * cartasJugables.length);
                cartaJugable = cartasJugables[randomIndex].carta;
                indiceCarta = cartasJugables[randomIndex].indice;
            }
        }

        if (!cartaJugable) {
            this.finalizarTurno();
            return;
        }

        const cartaHTML = this.crearHTMLCarta(cartaJugable);

        // Solo jugamos tropas
        const zonaTropas = document.querySelectorAll('.fila.tropas')[0].children;
        // Buscar un espacio vacío
        for (let i = 0; i < zonaTropas.length; i++) {
            if (zonaTropas[i].textContent === 'Tropa ' + (i + 1)) {
                this.tableroIA.tropas[i] = cartaJugable;
                zonaTropas[i].innerHTML = cartaHTML;
                this.manoIA.splice(indiceCarta, 1);
                this.oroIA -= cartaJugable.costo;
                // Robar una nueva carta si no excede el límite
                if (this.manoIA.length < 4) {
                    this.robarCarta(false);
                }
                break;
            }
        }

        // Intentar atacar con todas las tropas de la IA
        this.actualizarInterfaz();
        
        // Hacer que la IA ataque con todas sus tropas
        for (let i = 0; i < this.tableroIA.tropas.length; i++) {
            const tropa = this.tableroIA.tropas[i];
            if (tropa && !this.tableroIA.tropasAtacaron[i]) {
                this.realizarAtaqueIA(i);
            }
        }
        
        this.actualizarInterfaz();
        this.finalizarTurno();
    }

    // Función para finalizar el turno
    finalizarTurno() {
        // Fase de Fin
        // 1. Descartar efectos temporales (por implementar)
        // 2. Destruir unidades con 0 DEF
        const tablero = this.turnoJugador ? this.tableroJugador : this.tableroIA;
        for (let i = 0; i < tablero.tropas.length; i++) {
            if (tablero.tropas[i] && tablero.tropas[i].defensa <= 0) {
                tablero.tropas[i] = null;
            }
        }
        // 3. Robar una carta
        this.robarCarta(this.turnoJugador);
        
        // Cambiar el turno
        this.turnoJugador = !this.turnoJugador;

        // Inicio del nuevo turno
        // 1. Fase de Oro
        if (this.turnoJugador) {
            this.oroJugador = Math.min(this.oroJugador + 2, 10); // Máximo 10 de oro
            // TODO: Añadir oro de recursos
        } else {
            this.oroIA = Math.min(this.oroIA + 2, 10);
            setTimeout(() => this.turnoIA(), 1000);
        }

        // 2. Fase de Acción - Reiniciar estado de tropas
        const nuevoTablero = this.turnoJugador ? this.tableroJugador : this.tableroIA;
        nuevoTablero.tropasAtacaron.fill(false);

        this.actualizarInterfaz();
    }

    limpiarObjetivos() {
        // Limpiar objetivos válidos anteriores
        document.querySelectorAll('.objetivo-valido').forEach(elemento => {
            elemento.classList.remove('objetivo-valido');
            elemento.onclick = null;
        });
    }

    atacar(indiceAtacante, indiceObjetivo) {
        if (!this.turnoJugador) return; // Solo el jugador puede atacar manualmente

        // Limpiar objetivos antes de atacar
        this.limpiarObjetivos();

        const atacante = this.tableroJugador.tropas[indiceAtacante];
        if (!atacante || this.tableroJugador.tropasAtacaron[indiceAtacante]) return;

        // Buscar objetivo válido
        const tropasEnemigas = this.tableroIA.tropas.filter(tropa => tropa !== null);
        
        if (indiceObjetivo === -1) {
            // Atacar al castillo
            console.log(`${atacante.nombre} ataca al castillo enemigo`);
            console.log(`Daño al castillo: ${atacante.ataque}`);
            this.tableroIA.castillo.vida -= atacante.ataque;
            this.tableroJugador.tropasAtacaron[indiceAtacante] = true;
        } else if (tropasEnemigas.length > 0) {
            // Atacar a una tropa
            const objetivo = this.tableroIA.tropas[indiceObjetivo];
            if (!objetivo) return;
            this.resolverCombate(atacante, objetivo, indiceAtacante, indiceObjetivo);
        }

        this.actualizarInterfaz();
    }

    resolverCombate(atacante, objetivo, indiceAtacante, indiceObjetivo) {
        console.log(`${atacante.nombre} (ATK:${atacante.ataque}/DEF:${atacante.defensa}) ataca a ${objetivo.nombre} (ATK:${objetivo.ataque}/DEF:${objetivo.defensa})`);
        
        // Guardar los valores originales
        const defensaOriginalObjetivo = objetivo.defensa;
        const defensaOriginalAtacante = atacante.defensa;
        
        // Aplicar daño al objetivo
        objetivo.defensa -= atacante.ataque;
        console.log(`Daño infligido a ${objetivo.nombre}: ${atacante.ataque} (DEF restante: ${objetivo.defensa})`);
        
        // Contraataque si el objetivo sobrevive
        if (objetivo.defensa > 0) {
            console.log(`${objetivo.nombre} contraataca`);
            atacante.defensa -= objetivo.ataque;
            console.log(`Daño de contraataque a ${atacante.nombre}: ${objetivo.ataque} (DEF restante: ${atacante.defensa})`);
        }

        // Comprobar destrucción de unidades
        if (objetivo.defensa <= 0) {
            console.log(`${objetivo.nombre} ha sido destruido`);
            this.tableroIA.tropas[indiceObjetivo] = null;
        } else {
            // Si sobrevive, mantener la nueva defensa
            this.tableroIA.tropas[indiceObjetivo].defensa = objetivo.defensa;
        }

        if (atacante.defensa <= 0) {
            console.log(`${atacante.nombre} ha sido destruido`);
            this.tableroJugador.tropas[indiceAtacante] = null;
        } else {
            // Si sobrevive, mantener la nueva defensa
            this.tableroJugador.tropas[indiceAtacante].defensa = atacante.defensa;
        }

        // Marcar la unidad como que ya atacó este turno solo si sobrevive
        if (this.tableroJugador.tropas[indiceAtacante]) {
            this.tableroJugador.tropasAtacaron[indiceAtacante] = true;
        }

        // Marcar la unidad como que ya atacó este turno
        if (this.tableroJugador.tropas[indiceAtacante]) {
            this.tableroJugador.tropasAtacaron[indiceAtacante] = true;
        }

        // Actualizar la interfaz para mostrar los cambios
        this.actualizarInterfaz();
    }

    // Método para agregar interactividad a las cartas en el tablero
    hacerCartasInteractivas() {
        // Hacer las tropas del jugador interactivas para atacar
        const tropasPropias = document.querySelectorAll('.fila.tropas')[1].children;
        Array.from(tropasPropias).forEach((tropa, index) => {
            if (this.tableroJugador.tropas[index] && !this.tableroJugador.tropasAtacaron[index]) {
                tropa.classList.add('puede-atacar');
                tropa.onclick = () => this.seleccionarTropaAtacante(index);
            }
        });
    }

    realizarAtaqueIA(indiceAtacante) {
        const atacante = this.tableroIA.tropas[indiceAtacante];
        if (!atacante || this.tableroIA.tropasAtacaron[indiceAtacante]) return;

        // Buscar objetivo válido
        const tropasJugador = this.tableroJugador.tropas.filter(tropa => tropa !== null);
        
        if (tropasJugador.length > 0) {
            // Atacar la tropa con menos defensa
            let indiceObjetivo = -1;
            let menorDefensa = Infinity;
            
            this.tableroJugador.tropas.forEach((tropa, index) => {
                if (tropa && tropa.defensa < menorDefensa) {
                    menorDefensa = tropa.defensa;
                    indiceObjetivo = index;
                }
            });

            if (indiceObjetivo !== -1) {
                const objetivo = this.tableroJugador.tropas[indiceObjetivo];
                
                console.log(`IA: ${atacante.nombre} (ATK:${atacante.ataque}/DEF:${atacante.defensa}) ataca a ${objetivo.nombre} (ATK:${objetivo.ataque}/DEF:${objetivo.defensa})`);
                
                // Aplicar daño al objetivo
                objetivo.defensa -= atacante.ataque;
                console.log(`Daño infligido a ${objetivo.nombre}: ${atacante.ataque} (DEF restante: ${objetivo.defensa})`);

                // Contraataque si el objetivo sobrevive
                if (objetivo.defensa > 0) {
                    console.log(`${objetivo.nombre} contraataca`);
                    atacante.defensa -= objetivo.ataque;
                    console.log(`Daño de contraataque a ${atacante.nombre}: ${objetivo.ataque} (DEF restante: ${atacante.defensa})`);
                }

                // Comprobar destrucción de unidades
                if (objetivo.defensa <= 0) {
                    console.log(`${objetivo.nombre} ha sido destruido`);
                    this.tableroJugador.tropas[indiceObjetivo] = null;
                } else {
                    this.tableroJugador.tropas[indiceObjetivo].defensa = objetivo.defensa;
                }

                if (atacante.defensa <= 0) {
                    console.log(`${atacante.nombre} ha sido destruido`);
                    this.tableroIA.tropas[indiceAtacante] = null;
                } else {
                    this.tableroIA.tropas[indiceAtacante].defensa = atacante.defensa;
                }
            }
        } else {
            // Atacar al castillo del jugador
            this.tableroJugador.castillo.vida -= atacante.ataque;
            console.log(`IA: ${atacante.nombre} ataca al castillo (${atacante.ataque} daño)`);
        }

        this.tableroIA.tropasAtacaron[indiceAtacante] = true;
    }

    seleccionarTropaAtacante(indice) {
        if (!this.turnoJugador) return;

        // Limpiar objetivos anteriores
        this.limpiarObjetivos();

        // Guardar la tropa seleccionada para atacar
        this.tropaAtacanteSeleccionada = indice;

        // Verificar si hay tropas enemigas
        const hayTropasEnemigas = this.tableroIA.tropas.some(tropa => tropa !== null);

        if (hayTropasEnemigas) {
            // Hacer las tropas enemigas objetivos válidos
            const tropasEnemigas = document.querySelectorAll('.fila.tropas')[0].children;
            Array.from(tropasEnemigas).forEach((tropa, index) => {
                if (this.tableroIA.tropas[index]) {
                    tropa.classList.add('objetivo-valido');
                    tropa.onclick = () => this.atacar(this.tropaAtacanteSeleccionada, index);
                }
            });
        } else {
            // Hacer el castillo enemigo un objetivo válido
            const castilloEnemigo = document.querySelector('.castillo.enemigo');
            castilloEnemigo.classList.add('objetivo-valido');
            castilloEnemigo.onclick = () => this.atacar(this.tropaAtacanteSeleccionada, -1);
        }
    }

}

// Crear una instancia del juego cuando el DOM esté listo
document.addEventListener('DOMContentLoaded', () => {
    const juego = new Juego();
    juego.inicializarJuego();
    
    // Añadir evento al botón de terminar turno
    const btnTerminarTurno = document.getElementById('btn-terminar-turno');
    if (btnTerminarTurno) {
        btnTerminarTurno.addEventListener('click', () => {
            console.log('Botón terminar turno clickeado');  // Debug
            if (juego.turnoJugador) {
                console.log('Es turno del jugador, finalizando turno...');  // Debug
                juego.finalizarTurno();
                juego.actualizarInterfaz();
            }
        });
    } else {
        console.error('No se encontró el botón de terminar turno');  // Debug
    }
});